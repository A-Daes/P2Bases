# P2Bases

Modulo 1: 
CRM con capacidad de agregar, modificar y eliminar clientes, mostrar a estos con filtros y agregar nuevos campos a los clientes.

Checklist:
-GUI: [x] Opcional: Focus-only []
-Crear cliente []
-Editar cliente []
-Eliminar cliente []
-Crear filtro [] Opcional: Guardar filtros []
-Eliminar filtro [] Opcional: Solo desactivar []
-Agregar campo nuevo []
-Opcional: Usuarios con privilegios diferentes []
-Opcional: Encriptacion de datos []


Modulo 2:
Funcionalidad de conexion a twitter mediante MongoDB
Checklist: TBD



Dependencies:

-tkinter
-psycopg2
-pymongo
-tweepy
